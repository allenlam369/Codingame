import java.util.Scanner;

public class Agent1 {
    public static void main(String[] args) {
        String solution = "RURRDDDDLDRUUUULLLRDRDRDDLLDLLUUDR";
        for (char c : solution.toCharArray()) System.out.println(c);
    }
}
