This project is an example of a Solo game using the Game Engine Toolkit of [CodinGame](https://codingame.com).

Check the documentation on the [tech.io playground](https://www.codingame.com/playgrounds/25775/).
