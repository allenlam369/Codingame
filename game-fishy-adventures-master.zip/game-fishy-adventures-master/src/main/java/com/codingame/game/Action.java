package com.codingame.game;

public enum Action {
    UP, DOWN, STILL
}
