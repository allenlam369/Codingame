https://www.reddit.com/r/gamedev/comments/2rw8ya/1000_free_2d_sprites_animations_tiles_and_effects/

6 animated characters (school girl, business man, nurse, soldier, meathead, and cop + running animations)
a bunch of weapons (pistol, shotgun, smg, AR, minigun, flamethrower, tesla gun, frost gun, rocket launcher)
4 automatic turrets (machinegun, flame, frost, lightning)
5 animated enemies (walk, attack, die)
3 animated bosses (walk, attack, special attack, idle, etc)
floor tiles (grass and dungeon environment, tombstones, random items, castle walls, etc)
blood splats
gun flashes
explosions
enemy explosions
Effects such as sword swing, chainsaw swing, teleport smoke, and more
