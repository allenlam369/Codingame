# CameraModule

Contributed by [Butanium](https://github.com/Butanium).