/**
 *  The size of the drawspace on the viewer's canvas.
 */
export const WIDTH = 1920
export const HEIGHT = 1080

export const BASE_FRAME_DURATION = 500
