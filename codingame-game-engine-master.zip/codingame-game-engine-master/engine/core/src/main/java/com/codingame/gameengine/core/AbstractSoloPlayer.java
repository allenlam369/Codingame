package com.codingame.gameengine.core;

/**
 * The representation of the player's AI during the game's execution.
 *
 */
abstract public class AbstractSoloPlayer extends AbstractPlayer {

}
