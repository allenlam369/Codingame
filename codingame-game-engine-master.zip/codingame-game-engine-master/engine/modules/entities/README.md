# About

Check the [graphical entity engine](https://tech.io/playgrounds/25775/codingame-sdk-documentation/introduction-3).
