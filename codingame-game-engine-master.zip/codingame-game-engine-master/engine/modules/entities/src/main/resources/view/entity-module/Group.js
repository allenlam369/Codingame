import { ContainerBasedEntity } from './ContainerBasedEntity.js'

export class Group extends ContainerBasedEntity {
}
