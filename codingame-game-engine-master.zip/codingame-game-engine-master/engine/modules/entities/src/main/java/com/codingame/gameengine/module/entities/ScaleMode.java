package com.codingame.gameengine.module.entities;

public enum ScaleMode {
    LINEAR, NEAREST
}
