# About

Check the [game runner documentation](https://tech.io/playgrounds/25775/codingame-sdk-documentation/game-runner).
