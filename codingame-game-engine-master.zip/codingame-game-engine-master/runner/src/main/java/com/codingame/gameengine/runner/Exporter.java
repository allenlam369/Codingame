package com.codingame.gameengine.runner;

class Exporter {

    public static void main(String[] args) {
        Renderer.generateView(null, args[0]);
    }

}
