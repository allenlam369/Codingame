package com.codingame.gameengine.runner;

class MissingConfigException extends Exception {

    private static final long serialVersionUID = -2697528486967229871L;

    public MissingConfigException(String message) {
        super(message);
    }

}
