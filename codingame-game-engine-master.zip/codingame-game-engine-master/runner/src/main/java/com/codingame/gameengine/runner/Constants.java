package com.codingame.gameengine.runner;

class Constants {
    public static final int LANGUAGE_ID_FRENCH = 1;
    public static final int LANGUAGE_ID_ENGLISH = 2;
    public static final String[] LANGUAGE_CODE = new String[] { "fr", "en" };
}
