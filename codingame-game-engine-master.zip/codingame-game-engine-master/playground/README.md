# CodinGame SDK

The CodinGame SDK is a Java project that allows you to write programming games for [CodinGame](https://www.codingame.com).

This project is also a [Tech.io](https://tech.io) playground for the CodinGame SDK documentation.